package pl.com.bottega.ddd.support.domain;

public class BaseEntity {
	private Long entityId;

    public Long getEntityId() {
        return entityId;
    }
}
