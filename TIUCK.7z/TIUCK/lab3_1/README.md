## lab3_1
https://docs.google.com/document/d/1yWFtg7NuREJxlGKIeShBndPiXd6G9rR2D1QB_FjqTKw/edit?usp=sharing
