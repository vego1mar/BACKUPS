### Opis
https://docs.google.com/document/d/1lIRSDRuEooMIQjrcJwVbrF0ihfXyBT53Kj1RcuIqHqE/edit?usp=sharing 
