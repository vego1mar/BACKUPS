package com.danix.code.smell.example001;

/**
 * @author  danix
 */
public class CustomerTest { }
