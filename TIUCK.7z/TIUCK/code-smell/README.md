code-smell
==========

Code example for the [Refactoring Presentation](https://docs.google.com/presentation/d/1VjbJONDU3P9VAdB_HhhT1oBB4uOub80T_41yDmndwTw/edit?usp=sharing)
