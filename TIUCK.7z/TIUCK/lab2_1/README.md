## lab2_1

https://docs.google.com/document/d/1iAJEGBoq_JQ3lGPJFD3Uybq40yqroizqQdKl_M68BEQ/edit?usp=sharing
