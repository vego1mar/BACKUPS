package edu.iis.mto.time;

public class OrderStateException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OrderStateException(String info) {
		super(info);
	}

}
