### Opis
https://docs.google.com/document/d/144k-pW0DONAIkQtxVbMJZXQPbFlFcXgpelpQWmlKchA/edit?usp=sharing
